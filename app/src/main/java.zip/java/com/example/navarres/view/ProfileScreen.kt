package com.example.navarres.view

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.RestaurantMenu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.navarres.viewmodel.ProfileViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Colores Corporativos
private val NavarresRed = Color(0xFFB30000)
private val NavarresDarkRed = Color(0xFF800000)
private val NavarresGreen = Color(0xFF2E7D32)

// --- IMPORTANTE: FileProvider para la cámara ---
// Para que esto funcione, asegúrate de haber configurado el FileProvider
// en tu AndroidManifest.xml y creado el archivo res/xml/file_paths.xml
object ComposeFileProvider {
    fun getImageUri(context: Context): Uri {
        val directory = File(context.cacheDir, "images")
        directory.mkdirs()
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File.createTempFile(
            "JPEG_${timestamp}_",
            ".jpg",
            directory
        )
        val authority = "com.example.navarrest2.fileprovider"
        return FileProvider.getUriForFile(context, authority, file)
    }
}


@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel,
    onLogoutClick: () -> Unit
) {
    // 1. OBSERVAMOS LOS DATOS REALES DEL VIEWMODEL
    val userProfile by viewModel.userProfile.collectAsState()

    // UI State para cargas
    val uiState by viewModel.uiState.collectAsState()

    val scrollState = rememberScrollState()

    // Estados UI para diálogos
    var showEditBioDialog by remember { mutableStateOf(false) }
    var showEditCityDialog by remember { mutableStateOf(false) }

    // --- LÓGICA CÁMARA ---
    val context = LocalContext.current
    var tempPhotoUri by remember { mutableStateOf<Uri?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture(),
        onResult = { success ->
            if (success && tempPhotoUri != null) {
                viewModel.onPhotoTaken(tempPhotoUri!!)
            }
        }
    )

    fun launchCamera() {
        val uri = ComposeFileProvider.getImageUri(context)
        tempPhotoUri = uri
        cameraLauncher.launch(uri)
    }

    // --- PANTALLA PRINCIPAL ---
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF9F9F9))
            .verticalScroll(scrollState)
    ) {

        // 1. HEADER
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(NavarresRed, NavarresDarkRed)
                        )
                    )
            ) {
                Text(
                    text = "Perfil Gourmet",
                    color = Color.White.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.TopCenter)
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .size(140.dp)
            ) {
                // Elegir foto (UI State temporal o User Profile guardada)
                val currentPhoto = if(uiState.photoUrl.isNotEmpty()) uiState.photoUrl else userProfile.photoUrl

                if (currentPhoto.isNotEmpty()) {
                    AsyncImage(
                        model = currentPhoto,
                        contentDescription = "Foto de perfil",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .border(4.dp, Color.White, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        shape = CircleShape,
                        color = Color.White,
                        border = BorderStroke(4.dp, Color.White),
                        shadowElevation = 4.dp
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }

                // Spinner de carga
                if (uiState.isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center),
                        color = NavarresRed
                    )
                }

                SmallFloatingActionButton(
                    onClick = { if (!uiState.isLoading) launchCamera() }, // Evita clicks mientras carga
                    containerColor = NavarresGreen,
                    contentColor = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .offset(x = (-4).dp, y = (-4).dp),
                    shape = CircleShape
                ) {
                    Icon(Icons.Default.CameraAlt, "Editar", modifier = Modifier.size(18.dp))
                }
            }
        }

        // 2. DATOS BÁSICOS
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Safe string manipulation for name
            val displayName = if (userProfile.email.contains("@")) {
                userProfile.email.substringBefore("@").replaceFirstChar { it.uppercase() }
            } else {
                userProfile.email.ifEmpty { "Usuario" }
            }

            Text(
                text = displayName,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.Black
            )
            Text(
                text = if (userProfile.isEmailPublic) userProfile.email else "Email privado",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // 3. ESTADÍSTICAS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 40.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ProfileStatItem(number = "12", label = "Reseñas", icon = Icons.Outlined.RestaurantMenu)

            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(40.dp)
                    .background(Color.LightGray)
            )

            val favCount = userProfile.favorites.size.toString()
            ProfileStatItem(number = favCount, label = "Favoritos", icon = Icons.Outlined.FavoriteBorder)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 4. SECCIÓN BIOGRAFÍA
        ProfileSectionCard(title = "Sobre mí", onEditClick = { showEditBioDialog = true }) {
            Text(
                text = userProfile.bio.ifEmpty { "Escribe algo sobre tus gustos gastronómicos..." },
                style = MaterialTheme.typography.bodyLarge,
                color = if (userProfile.bio.isEmpty()) Color.Gray else Color(0xFF444444),
                lineHeight = 24.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 5. SECCIÓN INFORMACIÓN PERSONAL
        ProfileSectionCard(title = "Ajustes de Cuenta", showEdit = false) {

            // --- ROW EMAIL ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Email, null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Email público", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Text(userProfile.email, style = MaterialTheme.typography.bodyMedium)
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Switch(
                        checked = userProfile.isEmailPublic,
                        onCheckedChange = { isPublic ->
                            viewModel.updateEmailPrivacy(isPublic)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NavarresRed,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = Color.LightGray
                        ),
                        modifier = Modifier.graphicsLayer(scaleX = 0.8f, scaleY = 0.8f)
                    )
                    Text(
                        text = if (userProfile.isEmailPublic) "Visible" else "Oculto",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (userProfile.isEmailPublic) NavarresRed else Color.Gray,
                        fontSize = 10.sp
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color.LightGray.copy(alpha = 0.5f))

            // --- ROW CIUDAD ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showEditCityDialog = true },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Ubicación", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        if (userProfile.city.isNotEmpty()) {
                            Text(userProfile.city, style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                        } else {
                            Text("Añadir ciudad", style = MaterialTheme.typography.bodyMedium, color = NavarresRed, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // 6. BOTÓN CERRAR SESIÓN
        Button(
            onClick = {
                viewModel.logout()
                onLogoutClick()
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = NavarresRed
            ),
            // CORREGIDO: Se ha añadido el borde correctamente
            border = BorderStroke(1.dp, NavarresRed.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Cerrar Sesión")
        }

        Spacer(modifier = Modifier.height(32.dp))
    }

    // --- DIÁLOGOS DE EDICIÓN (Añadir la implementación si aún no la tienes) ---
    if (showEditBioDialog) {
        EditDialog(
            title = "Editar biografía",
            initialValue = userProfile.bio,
            onDismiss = { showEditBioDialog = false },
            onConfirm = { newBio ->
                viewModel.updateBio(newBio)
                showEditBioDialog = false
            }
        )
    }

    if (showEditCityDialog) {
        EditDialog(
            title = "Editar ciudad",
            initialValue = userProfile.city,
            onDismiss = { showEditCityDialog = false },
            onConfirm = { newCity ->
                viewModel.updateCity(newCity)
                showEditCityDialog = false
            }
        )
    }
}

// --- Componentes Auxiliares ---

@Composable
fun ProfileStatItem(number: String, label: String, icon: ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = number, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = Color.Black)
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSectionCard(
    title: String,
    showEdit: Boolean = true,
    onEditClick: () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                if (showEdit) {
                    IconButton(onClick = onEditClick, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Editar", tint = Color.Gray)
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun EditDialog(
    title: String,
    initialValue: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initialValue) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.SemiBold) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Escribe aquí...") },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NavarresRed,
                    cursorColor = NavarresRed
                )
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(text) },
                colors = ButtonDefaults.buttonColors(containerColor = NavarresRed)
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = Color.Gray)
            }
        }
    )
}